from openai import AzureOpenAI
import azure.functions as func
import os
import json
from azure.storage.blob import BlobServiceClient
import logging

client = AzureOpenAI(
    api_key=os.environ["AZURE_OPENAI_API_KEY"],
    azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
    api_version="2024-02-15-preview"
)

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Embed function called.')

    try:
        blob_service = BlobServiceClient.from_connection_string(os.environ["AZURE_STORAGE_CONNECTION"])
        chunks_container = blob_service.get_container_client("chunks")
        embeddings_container = blob_service.get_container_client("embeddings")

        embed_model = os.environ["AZURE_OPENAI_EMBED_MODEL"]

        count = 0

        for blob in chunks_container.list_blobs():
            chunk_text = chunks_container.get_blob_client(blob).download_blob().readall().decode("utf-8")

            result = client.embeddings.create(
                model=embed_model,
                input=chunk_text
            )

            embedding = result.data[0].embedding

            output = {
                "chunk_name": blob.name,
                "text": chunk_text,
                "embedding": embedding
            }

            embeddings_container.upload_blob(
                blob.name + ".json",
                json.dumps(output),
                overwrite=True
            )

            count += 1

        return func.HttpResponse(f"Generated embeddings for {count} chunks.")

    except Exception as e:
        logging.exception("Error in embed function")
        return func.HttpResponse(str(e), status_code=500)
