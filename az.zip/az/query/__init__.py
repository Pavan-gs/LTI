import logging
import os
import json
import math
import azure.functions as func
from azure.storage.blob import BlobServiceClient
from openai import OpenAI

from openai import AzureOpenAI
import os

client = AzureOpenAI(
    api_key=os.environ["AZURE_OPENAI_API_KEY"],
    azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
    api_version="2024-02-15-preview"
)

def cosine_similarity(a, b):
    dot = sum(x * y for x, y in zip(a, b))
    mag_a = math.sqrt(sum(x * x for x in a))
    mag_b = math.sqrt(sum(x * x for x in b))
    return dot / (mag_a * mag_b)

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Query function called.')

    question = req.params.get("q")
    if not question:
        return func.HttpResponse("Please pass ?q=your question", status_code=400)

    try:
        blob_service = BlobServiceClient.from_connection_string(os.environ["AZURE_STORAGE_CONNECTION"])
        embeddings_container = blob_service.get_container_client("embeddings")

        embed_model = os.environ["AZURE_OPENAI_EMBED_MODEL"]
        chat_model = os.environ["AZURE_OPENAI_CHAT_MODEL"]

        # embedding for question
        q_emb = client.embeddings.create(
            model=embed_model,
            input=question
        ).data[0].embedding

        # load all embeddings and compute similarity
        best_match = None
        best_score = -1

        for blob in embeddings_container.list_blobs():
            data = embeddings_container.get_blob_client(blob).download_blob().readall().decode("utf-8")
            record = json.loads(data)

            sim = cosine_similarity(q_emb, record["embedding"])

            if sim > best_score:
                best_score = sim
                best_match = record

        # Now ask the chat model with context
        prompt = f"""
You are an assistant for answering questions from FAQ.

Context:
{best_match["text"]}

Question: {question}

Answer based ONLY on the context above.
"""

        response = client.chat.completions.create(
            model=chat_model,
            messages=[{"role": "user", "content": prompt}]
        )

        answer = response.choices[0].message.content

        return func.HttpResponse(answer)

    except Exception as e:
        logging.exception("Query function error")
        return func.HttpResponse(str(e), status_code=500)
