import logging
import os
import json
import azure.functions as func
from azure.storage.blob import BlobServiceClient

def chunk_text(text: str, size: int = 200):
    words = text.split()
    return [" ".join(words[i:i + size]) for i in range(0, len(words), size)]

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Chunk function called.')

    blob_name = req.params.get("blob")
    if not blob_name:
        return func.HttpResponse("Please pass ?blob=faq.txt", status_code=400)

    try:
        blob_service = BlobServiceClient.from_connection_string(os.environ["AZURE_STORAGE_CONNECTION"])
        docs_container = blob_service.get_container_client("docs")

        # download the source FAQ file
        blob_client = docs_container.get_blob_client(blob_name)
        text = blob_client.download_blob().readall().decode("utf-8")

        # create text chunks
        chunks = chunk_text(text)

        # upload chunks to “chunks” container
        chunks_container = blob_service.get_container_client("chunks")

        for i, chunk in enumerate(chunks):
            chunk_name = f"{blob_name}_chunk_{i}.txt"
            chunks_container.upload_blob(chunk_name, chunk, overwrite=True)

        return func.HttpResponse(
            json.dumps({"chunks_created": len(chunks)}),
            mimetype="application/json"
        )

    except Exception as e:
        logging.exception("Chunk function error")
        return func.HttpResponse(str(e), status_code=500)
